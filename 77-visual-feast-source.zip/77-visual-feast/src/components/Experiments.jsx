import React, { useRef, useState } from 'react';

function Artwork({ index=0 }) {
  return <div className={`artwork artwork-${index%6}`}><i/><b/><span>{['ORBIT','FORM','AFTER','SLOW','ECHO','HERE'][index%6]}</span><small>77 / VISUAL STUDIES</small></div>;
}

export function CodropsEffect({ type, running }) {
  const [selected,setSelected] = useState(-1);
  const [spread,setSpread] = useState(false);
  const [progress,setProgress] = useState(0);
  const [trail,setTrail] = useState([]);
  const lastPoint = useRef({x:0,y:0});
  const sequence = useRef(0);
  const active = selected >= 0;
  const onWheel = event => setProgress(value => Math.max(0,Math.min(1,value+event.deltaY/900)));
  if(type === 'trail') return <div className="experiment trail-demo" onPointerMove={event=>{
    if(!running)return;
    const rect=event.currentTarget.getBoundingClientRect();
    const x=(event.clientX-rect.left)/rect.width*100,y=(event.clientY-rect.top)/rect.height*100;
    if(Math.hypot(x-lastPoint.current.x,y-lastPoint.current.y)<9)return;
    lastPoint.current={x,y};sequence.current+=1;
    setTrail(value=>[...value.slice(-7),{x,y,id:sequence.current}]);
  }}><div className="experiment-caption">LEAVE A<br/><em>little trace.</em><small>移动指针 · DRAW WITH MOTION</small></div>{trail.map(point=><div key={point.id} className="trail-picture" style={{left:point.x+'%',top:point.y+'%',rotate:(point.id%3*12-12)+'deg'}}><Artwork index={point.id}/></div>)}</div>;
  if(type === 'stack') return <div className="experiment stack-demo" onWheel={onWheel} onClick={()=>setProgress(value=>value>.5?0:1)}><div className="stack-scene">{[0,1,2,3,4].map(index=><div key={index} className="stack-sheet" style={{transform:`translateY(${(index-2)*(12+progress*40)}px) translateZ(${-index*20}px) rotateX(${35-progress*20}deg) rotateZ(${-20+progress*25}deg)`,zIndex:5-index}}><Artwork index={index}/></div>)}</div><small className="gesture">滚动或点击 · EXPLORE DEPTH</small></div>;
  if(type === 'elastic') return <div className="experiment elastic-demo" onWheel={onWheel} onPointerMove={event=>{const rect=event.currentTarget.getBoundingClientRect();setProgress((event.clientY-rect.top)/rect.height);}}>{[0,1,2].map(column=><div className="elastic-column" key={column} style={{transform:`translateY(${-progress*(column===1?120:65)}px)`,transitionDuration:column===1?'.2s':'.8s'}}>{[0,1,2].map(row=><Artwork key={row} index={column*2+row}/>)}</div>)}<small className="gesture">移动指针 / 滚动</small></div>;
  if(type === 'panels') return <div className={`experiment panels-demo ${spread?'spread':''}`} onClick={()=>setSpread(value=>!value)} onWheel={event=>setSpread(event.deltaY>0)}><div className="panel-one"><small>SELECTED WORK / 01</small><strong>Creative<br/><em>freedom.</em></strong></div><div className="panel-two"><Artwork index={1}/><b>A NEW<br/>PERSPECTIVE</b></div><small className="gesture">点击 / 滚动切换</small></div>;
  if(type === 'makeway' || type === 'zoom') return <div className={`experiment grid-demo ${type} ${active?'has-selection':''}`} onClick={()=>setSelected(-1)}>{Array.from({length:9},(_,index)=><div key={index} className={`grid-art ${selected===index?'selected':''}`} style={{'--column':index%3,'--row':Math.floor(index/3)}} onClick={event=>{event.stopPropagation();setSelected(selected===index?-1:index);}}><Artwork index={index}/></div>)}<small className="gesture">点击卡片 · 再次点击收起</small></div>;
  if(type === 'polaroid') return <div className={`experiment polaroid-demo ${spread?'spread':''}`} onClick={()=>setSpread(value=>!value)}>{Array.from({length:6},(_,index)=><div key={index} className="polaroid" style={{'--i':index,transform:spread?`translate(${(index%3-1)*105}px,${(Math.floor(index/3)-.5)*112}px) rotate(0deg)`:`translate(${(index%3-1)*12}px,${(index%2-.5)*15}px) rotate(${index*9-22}deg)`}}><Artwork index={index}/><span>memories, in motion</span></div>)}<small className="gesture">点击展开 / 收拢</small></div>;
  if(type === 'mask') return <div className={`experiment mask-demo ${spread?'spread':''}`} onClick={()=>setSpread(value=>!value)}><Artwork index={4}/><div className="mask-layer"><Artwork index={1}/></div><b>{spread?'ANOTHER WORLD':'CHANGE THE VIEW'}</b><small className="gesture">点击切换 · MASK REVEAL</small></div>;
  if(type === 'marquee') return <div className="experiment marquee-demo">{['IMAGINE','CREATE','REPEAT'].map((word,index)=><div className="marquee-row" key={word}><span>0{index+1}</span><b>{word}</b><div className="marquee-track"><div>{Array.from({length:6},(_,i)=><em key={i}>{word} ✳ </em>)}</div></div></div>)}</div>;
  return <div className="experiment repeat-demo">{Array.from({length:7},(_,index)=><div className="repeat-row" key={index} style={{'--i':index}}><span>MOVE. MOVE. MOVE. MOVE.</span></div>)}<small className="gesture">REPETITION IS A RHYTHM</small></div>;
}
