import React, { useEffect, useRef, useState } from 'react';
import { Player } from '@remotion/player';
import Aurora from '../vendor/react-bits/Aurora/Aurora';
import Silk from '../vendor/react-bits/Silk/Silk';
import Iridescence from '../vendor/react-bits/Iridescence/Iridescence';
import Waves from '../vendor/react-bits/Waves/Waves';
import Particles from '../vendor/react-bits/Particles/Particles';
import Orb from '../vendor/react-bits/Orb/Orb';
import ShinyText from '../vendor/react-bits/ShinyText/ShinyText';
import BlurText from '../vendor/react-bits/BlurText/BlurText';
import DecryptedText from '../vendor/react-bits/DecryptedText/DecryptedText';
import GradientText from '../vendor/react-bits/GradientText/GradientText';
import * as BlurSlideWord from '../vendor/remotion-bits/BlurSlideWord';
import * as GlitchIn from '../vendor/remotion-bits/GlitchIn';
import * as MultiTextTypewriter from '../vendor/remotion-bits/MultiTextTypewriter';
import * as BarChart from '../vendor/remotion-bits/BarChart';
import * as StatRings from '../vendor/remotion-bits/StatRings';
import * as CardStack from '../vendor/remotion-bits/CardStack';
import * as GridStagger from '../vendor/remotion-bits/GridStagger';
import * as ChatConversation from '../vendor/remotion-bits/ChatConversation';
import * as ParticlesSnow from '../vendor/remotion-bits/ParticlesSnow';
import * as LinearGradient from '../vendor/remotion-bits/LinearGradient';
import { CodropsEffect } from './Experiments';

const remotionEffects = { BlurSlideWord, GlitchIn, MultiTextTypewriter, BarChart, StatRings, CardStack, GridStagger, ChatConversation, ParticlesSnow, LinearGradient };
const remotionCompositions = Object.fromEntries(Object.entries(remotionEffects).map(([key, module]) => [key, function Composition() {
  const Content = module.Component;
  return <div style={{ width:'100%', height:'100%', position:'relative', display:'flex', justifyContent:'center', alignItems:'center', fontSize:100, background:'#11151c', color:'#f3efe6' }}><Content /></div>;
}]));

export class EffectBoundary extends React.Component {
  state = { failed:false };
  static getDerivedStateFromError() { return { failed:true }; }
  render() { return this.state.failed ? <div className="effect-error">当前浏览器无法运行这个效果<br/><a href={this.props.url} target="_blank" rel="noreferrer">打开官方演示 ↗</a></div> : this.props.children; }
}

export function Effect({ item, detailed=false, running=true, speed=1 }) {
  const [cycle, setCycle] = useState(0);
  const videoRef = useRef(null);
  useEffect(() => {
    if (!running || !['BlurText','DecryptedText'].includes(item.component)) return;
    const timer = setInterval(() => setCycle(value => value+1), 6500/speed);
    return () => clearInterval(timer);
  }, [item.component,running,speed]);
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.playbackRate = speed;
    if (running) video.play().catch(() => {}); else video.pause();
  }, [running,speed]);
  if (item.mode === 'video') return <video ref={videoRef} src={item.video} poster={item.poster} muted loop playsInline autoPlay={running} controls={detailed} preload="metadata" onError={event=>{event.currentTarget.parentElement.dataset.mediaError='true';}} />;
  if (item.source === 'Codrops') return <CodropsEffect type={item.component} running={running} />;
  if (item.source === 'Remotion Bits') {
    const module = remotionEffects[item.component];
    return <Player component={remotionCompositions[item.component]} durationInFrames={module.metadata.duration} compositionWidth={1920} compositionHeight={1080} fps={30} loop autoPlay={running} controls={detailed} playbackRate={speed} initiallyMuted style={{width:'100%',height:'100%'}} />;
  }
  const text = <span>MAKE IT<br/>MOVE.</span>;
  switch(item.component) {
    case 'Aurora': return <Aurora colorStops={['#b1ff92','#7855f7','#dbfcc5']} amplitude={1.15} blend={0.6} speed={speed*0.65} />;
    case 'Silk': return <Silk color="#ad9681" speed={speed*4} scale={1} noiseIntensity={0.7} />;
    case 'Iridescence': return <Iridescence color={[0.8,0.9,1]} speed={speed*0.6} amplitude={0.13} />;
    case 'Waves': return <Waves lineColor="#c4a7fb" backgroundColor="#191622" waveSpeedX={0.012*speed} waveSpeedY={0.006*speed} waveAmpX={26} waveAmpY={18} xGap={12} yGap={28} />;
    case 'Particles': return <Particles particleCount={140} particleColors={['#d9fbb1','#eeeeee','#ac98e9']} speed={speed*0.14} particleSpread={8} moveParticlesOnHover alphaParticles particleBaseSize={90} />;
    case 'Orb': return <Orb hue={270} hoverIntensity={0.5} rotateOnHover />;
    case 'ShinyText': return <div className="type-stage shiny-stage"><ShinyText text="Stay curious." speed={2.5/speed} color="#62655b" shineColor="#effacb" /></div>;
    case 'BlurText': return <div className="type-stage"><BlurText key={cycle} text="让 想象 流动" delay={180} animateBy="words" /></div>;
    case 'DecryptedText': return <div className="type-stage decrypt-stage"><DecryptedText key={cycle} text="HELLO, FUTURE." animateOn="view" revealDirection="start" sequential speed={60} /></div>;
    case 'GradientText': return <div className="type-stage"><GradientText colors={['#d5f5aa','#9d92f4','#e8afc8','#d5f5aa']} animationSpeed={5/speed}>{text}</GradientText></div>;
    default: return null;
  }
}
