import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Search, ArrowUpRight, ArrowRight, X, Heart, Grid2X2, Shuffle, Play, Pause, RotateCcw, Check, Copy, SlidersHorizontal, Menu, Sparkles, CircleHelp, Maximize2 } from 'lucide-react';
import catalog from './catalog.json';
import { Effect, EffectBoundary } from './components/Effects';
import './styles.css';

const sources=['React Bits','Remotion Bits','MotionKit','Codrops'];
const colors={'React Bits':'#bdacf5','Remotion Bits':'#9eceec','MotionKit':'#f2b088','Codrops':'#cff2a4'};
const modeLabels={component:'实时组件',video:'官方视频',adaptation:'交互演绎'};
const categories=['全部效果','动态文字','光影背景','粒子空间','布局转场','数据可视化','交互实验'];
const readSaved=()=>{try{return JSON.parse(localStorage.getItem('77-favorites')||'[]');}catch{return [];}};

function Preview({item, detailed=false, running=true, speed=1, replay=0}) {
  const holder=useRef(null);
  const [visible,setVisible]=useState(detailed);
  useEffect(()=>{
    if(detailed)return;
    const observer=new IntersectionObserver(([entry])=>setVisible(entry.isIntersecting),{rootMargin:'40px'});
    observer.observe(holder.current);return()=>observer.disconnect();
  },[detailed]);
  return <div ref={holder} className={`preview ${detailed?'detailed':''} ${running?'':'paused'}`}>
    {visible&&(running||item.mode==='video')&&<EffectBoundary key={item.id+'-'+replay} url={item.url}><Effect item={item} detailed={detailed} running={running} speed={speed}/></EffectBoundary>}
    {visible&&!running&&item.mode!=='video'&&<div className="preview-id">{item.title} · 动态预览已暂停</div>}
    {!visible&&<div className="preview-id">77 / {item.name}</div>}
    <div className="media-error">预览暂时无法加载 · 可从详情打开原站</div>
  </div>;
}

function Detail({item,onClose,saved,toggleSaved}) {
  const dialog=useRef(null);
  const [replay,setReplay]=useState(0);
  const [speed,setSpeed]=useState(1);
  const [copied,setCopied]=useState(false);
  const [tab,setTab]=useState('overview');
  useEffect(()=>{dialog.current.showModal();const previous=document.body.style.overflow;document.body.style.overflow='hidden';return()=>{document.body.style.overflow=previous;};},[]);
  async function copy(){try{await navigator.clipboard.writeText(item.url);setCopied(true);setTimeout(()=>setCopied(false),1800);}catch{setCopied(false);}}
  return <dialog ref={dialog} className="detail-dialog" onCancel={onClose} onClick={event=>{if(event.target===dialog.current)onClose();}} aria-labelledby="detail-title">
    <div className="dialog-top"><span><i style={{background:colors[item.source]}}/>{item.source} <b>/</b> {modeLabels[item.mode]}</span><button className="icon-button" aria-label="关闭详情" onClick={onClose}><X size={21}/></button></div>
    <Preview item={item} detailed speed={speed} replay={replay}/>
    <div className="preview-tools"><span>LIVE PREVIEW <i/> {item.tech}</span><div>{item.source==='Remotion Bits'||item.mode==='video'?<label>速度 <select value={speed} onChange={event=>setSpeed(Number(event.target.value))}><option value={.5}>0.5×</option><option value={1}>1×</option><option value={1.5}>1.5×</option><option value={2}>2×</option></select></label>:null}<button onClick={()=>setReplay(value=>value+1)}><RotateCcw size={14}/> 重播</button></div></div>
    <div className="detail-content"><div className="detail-heading"><div><p className="eyebrow">{item.category} / {item.name}</p><h2 id="detail-title">{item.title}</h2></div><button className={`save-large ${saved?'saved':''}`} onClick={()=>toggleSaved(item.id)}><Heart size={18} fill={saved?'currentColor':'none'}/>{saved?'已收藏':'收藏效果'}</button></div>
    <div className="detail-tabs"><button className={tab==='overview'?'active':''} onClick={()=>setTab('overview')}>效果说明</button><button className={tab==='source'?'active':''} onClick={()=>setTab('source')}>来源与使用</button>{item.parameters?.length>0&&<button className={tab==='params'?'active':''} onClick={()=>setTab('params')}>原站参数</button>}</div>
    {tab==='overview'&&<div className="detail-description"><p>{item.description}</p><div className="specs"><span>来源<b>{item.source}</b></span><span>预览方式<b>{modeLabels[item.mode]}</b></span><span>交互提示<b>{item.source==='Codrops'?'按画面提示操作':item.mode==='video'?'播放 / 暂停 / 拖动进度':'移动指针或观看循环'}</b></span></div></div>}
    {tab==='source'&&<div className="detail-description"><p>{item.mode==='adaptation'?'本页为根据该 Codrops 案例交互思路独立制作的轻量演绎，使用原创抽象画面；完整原作请打开官方演示。':item.mode==='video'?'此处播放 MotionKit 原站提供的官方预览视频。模板参数与编辑功能请在 MotionKit 原站使用。':'本页运行原项目的开源组件，示例文字、配色和展示容器已适配。请通过原站获取安装方式与完整文档。'}</p><p className="muted">作者：{item.author}。作品及源码权利归各自作者所有，具体使用条件见原站与 THIRD_PARTY_NOTICES.md。</p></div>}
    {tab==='params'&&<div className="parameter-list">{item.parameters.map(param=><div key={param.name}><span>{param.label}</span><code>{String(param.default??'—')}</code></div>)}<small>以上为原站默认参数；在此展示，不会修改官方预览视频。</small></div>}
    <div className="detail-actions"><a href={item.url} target="_blank" rel="noreferrer" className="primary-link">打开官方演示 <ArrowUpRight size={17}/></a>{item.codeUrl&&<a href={item.codeUrl} target="_blank" rel="noreferrer" className="secondary-link">查看原始源码 <ArrowUpRight size={16}/></a>}<button className="secondary-link" onClick={copy}>{copied?<Check size={16}/>:<Copy size={16}/>} {copied?'已复制':'复制来源链接'}</button></div></div>
  </dialog>;
}

function App(){
  const [source,setSource]=useState('全部来源');
  const [category,setCategory]=useState('全部效果');
  const [query,setQuery]=useState('');
  const [saved,setSaved]=useState(readSaved);
  const [favorites,setFavorites]=useState(false);
  const [selected,setSelected]=useState(null);
  const [sort,setSort]=useState('curated');
  const [playing,setPlaying]=useState(()=>!matchMedia('(prefers-reduced-motion: reduce)').matches);
  const [mobileMenu,setMobileMenu]=useState(false);
  const [about,setAbout]=useState(false);
  const search=useRef(null);
  const grid=useRef(null);
  const items=useMemo(()=>{
    let list=catalog.filter(item=>(source==='全部来源'||item.source===source)&&(category==='全部效果'||item.category===category)&&(!favorites||saved.includes(item.id))&&`${item.title} ${item.name} ${item.category} ${item.source} ${item.description}`.toLowerCase().includes(query.toLowerCase().trim()));
    if(sort==='name')list=[...list].sort((a,b)=>a.title.localeCompare(b.title,'zh-CN'));
    if(sort==='curated'&&source==='全部来源')list=[...list].sort((a,b)=>catalog.indexOf(a)%10-catalog.indexOf(b)%10 || sources.indexOf(a.source)-sources.indexOf(b.source));
    return list;
  },[source,category,query,favorites,saved,sort]);
  useEffect(()=>{try{localStorage.setItem('77-favorites',JSON.stringify(saved));}catch{}},[saved]);
  useEffect(()=>{const listener=event=>{if(event.key==='/'&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)&&!selected){event.preventDefault();search.current?.focus();} };window.addEventListener('keydown',listener);return()=>window.removeEventListener('keydown',listener);},[selected]);
  const toggleSaved=id=>setSaved(value=>value.includes(id)?value.filter(key=>key!==id):[...value,id]);
  const chooseSource=name=>{setSource(name);setMobileMenu(false);};
  const reset=()=>{setSource('全部来源');setCategory('全部效果');setQuery('');setFavorites(false);};
  return <><aside className={`sidebar ${mobileMenu?'open':''}`}><a href="#" className="brand" onClick={event=>{event.preventDefault();reset();}}><div className="brand-mark">77<span>✳</span></div><div className="brand-copy">视觉盛宴<small>VISUAL FEAST</small></div></a><div className="workspace-label">YOUR CREATIVE PLAYGROUND</div><nav><button className={!favorites?'nav-link active':'nav-link'} onClick={()=>{reset();setMobileMenu(false);}}><Grid2X2 size={17}/>全部灵感<span>40</span></button><button className={favorites?'nav-link active':'nav-link'} onClick={()=>{setFavorites(true);setSource('全部来源');setCategory('全部效果');setQuery('');setMobileMenu(false);}}><Heart size={17}/>我的收藏<span>{saved.length.toString().padStart(2,'0')}</span></button></nav><div className="nav-heading">精选来源 <span>04</span></div><div className="source-nav">{sources.map((name,index)=><button key={name} className={source===name?'selected':''} onClick={()=>chooseSource(name)}><i style={{background:colors[name]}}/><span>{name}</span><small>10</small></button>)}</div><div className="sidebar-note"><span className="note-star">✳</span><p>好创意，<br/>值得反复观看。</p><small>A little motion.<br/>A lot of inspiration.</small></div><div className="sidebar-bottom"><span><i/> 40 个精选动态实验</span><button onClick={()=>setAbout(true)}><CircleHelp size={15}/>关于这个展厅<ArrowUpRight size={14}/></button></div></aside>
  {mobileMenu&&<button className="mobile-scrim" aria-label="收起菜单" onClick={()=>setMobileMenu(false)}/>}
  <main><header className="topbar"><div><button className="mobile-toggle icon-button" aria-label="打开菜单" onClick={()=>setMobileMenu(!mobileMenu)}><Menu size={21}/></button><span>77'S COLLECTION</span><b>/</b><strong>{favorites?'我的收藏':'动效灵感库'}</strong></div><span className="edition">CURATED WITH CURIOSITY <i/> VOL. 01</span></header>
  <section className="hero"><div className="hero-copy"><div className="eyebrow"><span className="live-dot"/> A COLLECTION OF MOVING IDEAS</div><h1>77的<span>视觉盛宴</span><span className="hero-asterisk">✳</span></h1><p>让灵感动起来。<br className="mobile-break"/> 在 40 个视觉实验里，发现下一个好镜头。</p><div className="hero-actions"><button className="hero-cta" onClick={()=>grid.current?.scrollIntoView({behavior:'smooth',block:'start'})}>开始探索 <ArrowRight size={17}/></button><span>4 个创意来源 <b>·</b> 每站精选 10 个</span></div></div><div className="hero-art" aria-hidden="true"><div className="orbital-lines"><i/><i/><i/><i/><i/></div><div className="hero-orbit"></div><span className="art-top">PLAY. EXPLORE. REPEAT.</span><span className="art-bottom">MOTION IS A FEELING <span>↗</span></span><div className="art-stamp">77<br/><small>SELECTED<br/>VISUALS</small></div></div></section>
  <section className="collection" ref={grid}><div className="collection-heading"><div><span className="section-number">01 —</span><h2>{favorites?'我的收藏':'发现动态灵感'}</h2><span className="item-count">{items.length.toString().padStart(2,'0')}</span></div><button className="shuffle" onClick={()=>{if(items.length)setSelected(items[Math.floor(Math.random()*items.length)]);}} disabled={!items.length}><Shuffle size={15}/>给我一点灵感</button></div>
  <div className="toolbar"><div className="search"><Search size={18}/><input ref={search} placeholder="搜索效果、关键词或来源…" value={query} onChange={event=>setQuery(event.target.value)} aria-label="搜索动态特效"/>{query?<button className="icon-button" aria-label="清空搜索" onClick={()=>setQuery('')}><X size={14}/></button>:<kbd>/</kbd>}</div><label className="source-select"><SlidersHorizontal size={15}/><select aria-label="筛选来源" value={source} onChange={event=>setSource(event.target.value)}><option>全部来源</option>{sources.map(name=><option key={name}>{name}</option>)}</select></label><select className="sort-select" aria-label="排序方式" value={sort} onChange={event=>setSort(event.target.value)}><option value="curated">精选排序</option><option value="name">名称排序</option></select><button title={playing?'暂停动态预览':'播放动态预览'} className={`play-toggle ${playing?'on':''}`} onClick={()=>setPlaying(value=>!value)}>{playing?<Pause size={15}/>:<Play size={15}/>}<span>{playing?'预览中':'已暂停'}</span></button></div>
  <div className="category-pills">{categories.map(name=><button key={name} className={category===name?'active':''} onClick={()=>setCategory(name)}>{name}{name==='全部效果'&&<span>40</span>}</button>)}</div>
  <div className="results-meta"><span>{source==='全部来源'?'来自四个创意社区的精选':source+' 精选'} <b> / </b> {items.length} 个效果</span><span><span className="tiny-dot"/> 点击查看大屏预览与来源</span></div>
  <div className="effects-grid">{items.map(item=><article className="effect-card" key={item.id}><div className="card-visual"><Preview item={item} running={playing&&!selected} /><span className="mode-badge"><i/>{modeLabels[item.mode]}</span><button className={`favorite-button ${saved.includes(item.id)?'saved':''}`} aria-label={`${saved.includes(item.id)?'取消收藏':'收藏'}${item.title}`} aria-pressed={saved.includes(item.id)} onClick={()=>toggleSaved(item.id)}><Heart size={16} fill={saved.includes(item.id)?'currentColor':'none'}/></button><button className="expand-preview" aria-label={`预览${item.title}`} onClick={()=>setSelected(item)}><Maximize2 size={15}/></button></div><button className="card-info" onClick={()=>setSelected(item)}><div><span className="card-category">{item.category}</span><h3>{item.title}<ArrowUpRight size={17}/></h3><p>{item.name}</p></div><div className="card-footer"><span><i style={{background:colors[item.source]}}/>{item.source}</span><span>查看效果 <ArrowRight size={12}/></span></div></button></article>)}</div>
  {!items.length&&<div className="empty-state"><Search size={34}/><h3>{favorites?'还没有匹配的收藏':'没有找到匹配的效果'}</h3><p>{favorites?'点击效果卡片上的爱心，收集你喜欢的灵感。':'试试“文字”“粒子”，或清除筛选条件。'}</p><button onClick={reset}>查看全部 40 个效果 <ArrowRight size={15}/></button></div>}
  <footer><span>77的视觉盛宴 <b>✳</b> 为灵感留一个位置。</span><button onClick={()=>setAbout(true)}>来源与致谢 <ArrowUpRight size={14}/></button></footer></section></main>
  {selected&&<Detail key={selected.id} item={selected} onClose={()=>setSelected(null)} saved={saved.includes(selected.id)} toggleSaved={toggleSaved}/>}
  {about&&<About onClose={()=>setAbout(false)}/>}
  </>;
}

function About({onClose}){const ref=useRef(null);useEffect(()=>{ref.current.showModal();},[]);return <dialog ref={ref} className="about-dialog" onCancel={onClose} onClick={event=>{if(event.target===ref.current)onClose();}}><button className="icon-button about-close" aria-label="关闭说明" onClick={onClose}><X size={20}/></button><div className="eyebrow">A PERSONAL MOTION COLLECTION</div><h2>关于这场视觉盛宴</h2><p>从四个创意网站各选取 10 个效果，收集成随时可以打开的动态灵感库。</p><ul><li><b>React Bits / Remotion Bits</b>：实际开源组件，文字和配色适配展厅。</li><li><b>MotionKit</b>：原站官方视频预览，播放需要网络。</li><li><b>Codrops</b>：10 个案例的轻量交互演绎，完整作品通过原站链接访问。</li></ul><p>收藏保存在当前浏览器；清除网站数据会清空收藏。所有条目保留来源，各项目版权与许可仍归原作者。</p><div className="about-sources">{sources.map((name,index)=><a key={name} href={['https://reactbits.dev/','https://remotion-bits.dev/','https://remotion-kit.com/marketplace','https://tympanus.net/codrops/hub/'][index]} target="_blank" rel="noreferrer">{name}<ArrowUpRight size={15}/></a>)}</div></dialog>;}

createRoot(document.getElementById('root')).render(<App/>);
