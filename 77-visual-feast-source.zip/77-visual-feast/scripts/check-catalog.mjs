import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
const catalog=JSON.parse(readFileSync('src/catalog.json','utf8'));
assert.equal(catalog.length,40);
assert.equal(new Set(catalog.map(item=>item.id)).size,40);
for(const source of ['React Bits','Remotion Bits','MotionKit','Codrops']) assert.equal(catalog.filter(item=>item.source===source).length,10,source);
for(const item of catalog){
  assert.ok(item.title&&item.description&&item.category);
  assert.equal(new URL(item.url).protocol,'https:');
  if(item.mode==='video')assert.ok(item.video.startsWith('https://'));
  if(item.source==='React Bits')assert.ok(existsSync(`src/vendor/react-bits/${item.component}/${item.component}.jsx`));
  if(item.source==='Remotion Bits')assert.ok(existsSync(`src/vendor/remotion-bits/${item.component}.tsx`));
}
console.log('PASS: 40 unique effects, exactly 10 per source; source URLs, metadata and local components valid.');
