import { readFileSync, writeFileSync, readdirSync, unlinkSync, rmdirSync } from 'node:fs';
let html=readFileSync('dist/index.html','utf8');
html=html.replace(/<script type="module" crossorigin src="\.\/([^\"]+)"><\/script>/g,(_,file)=>`<script type="module">${readFileSync('dist/'+file,'utf8').replace(/<\/script/gi,'<\\/script')}</script>`);
html=html.replace(/<link rel="stylesheet" crossorigin href="\.\/([^\"]+)">/g,(_,file)=>`<style>${readFileSync('dist/'+file,'utf8')}</style>`);
const upstreamLicense=readFileSync('src/vendor/react-bits/LICENSE.txt','utf8');
html=html.replace('</head>',`<!-- React Bits upstream license (David Haz):\n${upstreamLicense.replace(/--/g,'—')}\nOther project notices: THIRD_PARTY_NOTICES.md -->\n</head>`);
writeFileSync('dist/index.html',html);
console.log('Self-contained page:',Math.round(Buffer.byteLength(html)/1024),'KiB');
